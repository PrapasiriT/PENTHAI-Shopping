-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2024 at 06:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `beautystore`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `CartID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdatedAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ProductName` varchar(255) DEFAULT NULL,
  `ImageURL` varchar(255) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart_items`
--

INSERT INTO `cart_items` (`CartID`, `UserID`, `ProductID`, `Quantity`, `CreatedAt`, `UpdatedAt`, `ProductName`, `ImageURL`, `Price`) VALUES
(3, 2, 2, 1, '2024-12-24 16:27:37', '2024-12-24 16:27:37', 'WINK WHITE XS PROTEIN', '/uploads/1734778374350.jpg', NULL),
(4, 2, 5, 2, '2024-12-24 16:32:52', '2024-12-24 16:39:29', 'VASELINE HEALTHY BRIGHT UV EXTRA BRIGHTENING+GLUTA CERAMIDE LOTION', '/uploads/1734794695086.png', NULL),
(5, 2, 1, 3, '2024-12-24 16:35:35', '2024-12-24 17:27:49', 'Pinkflash Ombrelips 2 In 1 ลิปสติก', '/uploads/1734769285451.png', 52.00),
(6, 2, 4, 1, '2024-12-24 16:43:09', '2024-12-24 16:43:09', 'Sasi Acne Sol Comfort Powder', '/uploads/1734787105803.jpg', 89.00);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CategoryID`, `CategoryName`) VALUES
(1, 'เครื่องสำอาง'),
(2, 'บำรุงผิวกาย'),
(3, 'บำรุงผิวหน้า'),
(4, 'อาหารเสริม');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `OrderDetailID` int(11) NOT NULL,
  `OrderID` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `OrderStatus` enum('Pending','Completed','Cancelled') NOT NULL,
  `OrderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `ShippingAddress` text NOT NULL,
  `PaymentMethod` enum('Credit Card','PayPal','Bank Transfer') NOT NULL,
  `TotalAmount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductID` int(11) NOT NULL,
  `ProductName` varchar(255) NOT NULL,
  `Description` text DEFAULT NULL,
  `Price` decimal(10,2) NOT NULL,
  `StockQuantity` int(11) NOT NULL,
  `ImageURL` varchar(255) DEFAULT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdatedAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `CategoryID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `ProductName`, `Description`, `Price`, `StockQuantity`, `ImageURL`, `CreatedAt`, `UpdatedAt`, `CategoryID`) VALUES
(1, 'Pinkflash Ombrelips 2 In 1 ลิปสติก', '#DoubleSense Series มาพร้อมลิปสติก 3 แบบ ได้แก่\r\n【2 In 1 Liquid Matte Lipstick】ปลายทั้งสองข้างเป็นพื้นผิวแบบลิควิดที่มีสีต่างกัน เม็ดสีสูง ป้องกันการถ่ายโอน ไม่ติดแก้ว ไม่แตก กันน้ำ และติดทนยาวนาน\r\n【 2 In 1 Misty Velvet Lip Tint 】ปลายทั้งสองข้างเป็นเนื้อกำมะหยี่นุ่มที่มีสีต่างกัน เม็ดสีสูง น้ำหนักเบา ทาสบาย กันน้ำ และติดทนนาน\r\n【 2 In 1 Double Effect Matte Lipstick 】ปลายด้านหนึ่งเป็นพื้นผิวด้านของเหลวและปลายอีกด้านหนึ่งเป็นเนื้อกำมะหยี่นุ่ม ให้พื้นผิวแมตต์เป็นพิเศษและผิวเคลือบกำมะหยี่แบบมิสต์พร้อมๆ กัน ง่ายต่อการจัดการกับเอฟเฟกต์การแต่งหน้าสำหรับโอกาสต่างๆ', 52.00, 10, '/uploads/1734769285451.png', '2024-12-21 08:21:25', '2024-12-21 13:52:42', 1),
(2, 'WINK WHITE XS PROTEIN', '🩷WHEY L-CARNITINE PINK MILK\r\n\r\nคุมหิว เร่งเผาผลาญ\r\n\r\nเวย์โปรตีน ISOLATE CONCENTRATE 100% PREMIUM FROM USA โปรตีนสูง 23 G.\r\n\r\n0% NO SUGAR 100 Kcal.\r\n\r\n✅BLOCK&BURN\r\n\r\nมี วิตามิน 15 ชนิด กรดอะมิโนจำเป็น 14 ชนิด\r\n\r\nL-Carnitine เร่งเผาผลาญ ลดไขมันสะสม\r\n\r\nCLA ยับยั้งการสะสมของไขมันใหม่ เร่งสลายไขมันส่วนเกิน เสริมสร้างมวลกล้ามเนื้อให้แข็งแรง \r\n\r\nCreatine บำรุงกล้ามเนื้อ ลดการสลายตัวของกล้ามเนื้อเมื่อมีการเร่งเบิร์น ช่วยให้ออกกำลังกายได้ทน ลดความล้า กระชับสัดส่วน', 490.00, 10, '/uploads/1734778374350.jpg', '2024-12-21 10:52:54', '2024-12-21 13:52:53', 4),
(3, 'The Charming Garden : JELLY FIBER - Dietary Supplement', 'Jelly Fiber The Charming Garden🍒\r\nเจลลี่ไฟเบอร์\r\nช่วยปรับสมดุลขับถ่าย ฟื้นฟูการทำงานของลำไส้ ให้กลับมาทำงานเป็นปกติ ไม่มีส่วนผสมของยาระบาย จึงไม่ทำให้ปวดบิด ไม่ทรมาน \r\n💗ล้างลำไส้ \r\n💗ปรับสมดุลขับถ่าย \r\n💗พุงยุบ \r\n💗น้ำหนักลดลงได้หากทานอย่างต่อเนื่อง', 175.00, 5, '/uploads/1734786963823.jpg', '2024-12-21 13:16:03', '2024-12-21 13:53:04', 4),
(4, 'Sasi Acne Sol Comfort Powder', 'แป้งอัดแข็ง ศศิ แอคเน่ โซล คอมฟอร์ท พาวเดอร์ Sasi Acne Sol Comfort Powder SPF23 PA+++\r\n\r\n- แป้งอัดแข็งเนื้อสีเขียว \r\n- เนื้อละเอียดบางเบา \r\n- ไม่อุดตันผิว ช่วยเบลอรูขุมขน\r\n', 89.00, 10, '/uploads/1734787105803.jpg', '2024-12-21 13:18:25', '2024-12-21 13:53:13', 1),
(5, 'VASELINE HEALTHY BRIGHT UV EXTRA BRIGHTENING+GLUTA CERAMIDE LOTION', 'ยูวี ไลท์เทนนิ่ง + กลูต้า เซราไมด์  โลชั่น สูตรที่ผ่านการการพิสูจน์ทางคลินิกพร้อมด้วย\r\n\r\n- แอ็คทีฟไนอะซินาไมด์ 10 เท่า\r\n\r\n- เทคโนโลยีกลูต้าโกลว์TM สิทธิบัตรเฉพาะของวาสลีน ที่มีประสิทธิภาพเป็นแอนตี้ออกซิแดนท์มากกว่าวิตามินซี 10 เท่า\r\n\r\n- ผสานกลูต้าไธโอนที่เป็นที่รู้กันว่าเป็นแอนตี้ออกซิแดนท์ที่มีประสิทธิภาพ\r\n\r\n- ทริปเปิ้ล ซันสกรีน ช่วยป้องกันผิวหมองคล้ำจากการถูกทำร้ายจากแสงแดดได้ถึง 87\r\n\r\n- วาสลีนเจลลี่ ช่วยล็อคความชุ่มชื่นล้ำลึกในชั้นผิว คืนความสมดุลตามธรรมชาติสู่ผิวคุณ\r\n\r\n- สัมผัสประสบการณ์ผิวกระจ่างใสขึ้น 1 เฉด และเนียนลื่นขึ้น ภายในเวลาเพียง 7 วัน\r\n\r\n- ไม่เหนอะหนะผิว\r\n\r\nผ่านการทดสอบโดยผู้เชี่ยวชาญด้านผิวหนัง เมื่อเทียบวิตามินบี 3 กับวาสลีน เฮลธี้ ไวท์ เอสพีเอฟ24 พีเอ++ ด้วย SPF \r\n\r\nผิวชั้นนอก ผลทดสอบทางคลินิกเมื่อใช้เป็นประจำ ผลลัพธ์ขึ้นอยู่กับสภาพผิวแต่ละบุคคล เครื่องสำอางไม่สามารถเปลี่ยนแปลงสีผิวตามธรรมชาติได้ ความชุ่มชื่น', 219.00, 10, '/uploads/1734794695086.png', '2024-12-21 15:24:55', '2024-12-21 15:24:55', 2),
(6, 'MizuMi Peptide Acne Gel', 'มิซึมิ เปปไทด์ แอคเน่ เจล (9g x 1 หลอด)\r\n เจลแต้มสิวเปปไทด์ สูตรเร่งด่วน แรงและเร็ว! \r\nลดการอักเสบสิวภายใน 24 ชั่วโมง \r\n•ลดการอักเสบสิวภายใน 24 ชม. \r\n Phytosaccharide สารสกัดจากสาหร่ายสีน้ำตาล \r\n•ช่วยยับยั้งการเติบโตของ P. Acne \r\n•ลดการผลิตน้ำมันจากต่อมไขมัน\r\nVitamin B3 และสารสกัดจากชะเอมเทศ \r\n•ช่วยลดรอยแดง รอยหมองคล้ำ และจุดด่างดำจากสิว \r\n•อโลเวราและใบบัวบกช่วยปลอบประโลมผิว \r\n•ลดการอักเสบและการระคายเคืองผิว\r\n Oligopeptide-10 อะมิโนสกัดจากพืช\r\n•ทำงานเลียนแบบภูมิคุ้มกันของร่างกาย ต่อต้านเชื้อแบคทีเรีย \r\n ลดโอกาสการเกิดรอยแดง รอยดำ และแผลเป็นจากสิว \r\n เนื้อเจลซึมเร็ว แห้งไว ไม่รบกวนการแต่งหน้า\"\r\n️วิธีใช้  แต้มบริเวณสิว 1-3 ครั้ง/วัน จนกว่าสิวจะยุบ ใช้ได้บ่อยเท่าที่ต้องการ', 85.00, 5, '/uploads/1735014715568.jpg', '2024-12-24 04:31:55', '2024-12-24 04:31:55', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `FirstName`, `LastName`, `Email`, `Password`, `CreatedAt`) VALUES
(1, 'pim', 'pim', 'pim@pim', '123456', '2024-12-24 03:43:37'),
(2, 'pphakarn', 'ho', 'pi@gmail.com', '$2b$10$veoJoz9qtuyaqFDibOG0FOYC5./jkZCuon/VSs9eicd8FfnFVPPXe', '2024-12-24 04:03:32'),
(3, 'friend', 'pha', 'po@gmail.com', '$2b$10$CyMi.rkeMXD6i1P2L2CyZ.3Ol3BnbEKJs1UxRYoowEfH5M.zLltwC', '2024-12-24 15:37:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`CartID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `ProductID` (`ProductID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`CategoryID`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`OrderDetailID`),
  ADD KEY `OrderID` (`OrderID`),
  ADD KEY `ProductID` (`ProductID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductID`),
  ADD KEY `CategoryID` (`CategoryID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `CartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `CategoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `OrderDetailID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `cart_items_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`),
  ADD CONSTRAINT `cart_items_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `products` (`ProductID`);

--
-- Constraints for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `orderdetails_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`) ON DELETE CASCADE,
  ADD CONSTRAINT `orderdetails_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `products` (`ProductID`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `categories` (`CategoryID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
