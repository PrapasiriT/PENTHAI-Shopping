const express = require('express');
const path = require('path'); // To handle paths more efficiently
const session = require('express-session'); // Require session
const usersRouter = require('./routes/users'); // Import Users Router
const productsRouter = require('./routes/products');
const checkoutRoutes = require('./routes/checkout');

const app = express();

// กำหนดการใช้ session ใน app
app.use(session({
  secret: 'your-secret-key', // คีย์ที่ใช้ในการเข้ารหัส session
  resave: false,             // ไม่ต้องบันทึก session ใหม่ถ้าไม่มีการเปลี่ยนแปลง
  saveUninitialized: true    // ให้บันทึก session เมื่อเริ่มต้นใช้งาน
}));

// Middleware
app.use(express.json()); // Built-in middleware to parse JSON bodies
app.use(express.urlencoded({ extended: true })); // Built-in middleware to parse URL-encoded data

app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/users', usersRouter);
app.use('/products', productsRouter);

app.use('/checkout', checkoutRoutes);

// Set View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Home route
app.get('/', (req, res) => {
  res.render('index', {
    isLoggedIn: req.session.isLoggedIn || false, // Check if user is logged in
    FirstName: req.session.FirstName || '' // Get the user's first name from the session
  });
});

// Register route (render EJS view instead of sending HTML)
app.get('/register', (req, res) => {
  res.render('register');
});

// Add Product route (render EJS view instead of sending HTML)
// ตรวจสอบสถานะล็อกอิน
app.get('/add', (req, res) => {
  if (req.session.isLoggedIn) {
    res.render('add-product');
  } else {
    res.redirect('/login'); // หากไม่ได้ล็อกอินให้ไปหน้าล็อกอิน
  }
});

// Login route (render EJS view instead of sending HTML)
app.get('/login', (req, res) => {
  res.render('login');
});

// Redirect to product list
app.get('/product', (req, res) => {
  res.redirect('/products/product');
});

// Correct parameterized route for product
app.get('/product/:id', (req, res) => {
  const productId = req.params.id;
  res.redirect(`/products/product/${productId}`); // Redirect correctly with the product id
});

// Correct parameterized route for category
app.get('/category/:CategoryID', (req, res) => {
  const CategoryID = req.params.CategoryID; // Use the correct parameter name
  res.redirect(`/products/category/${CategoryID}`);
});

// Login POST route to handle login logic
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  // ตัวอย่างการตรวจสอบ username และ password
  if (username === 'user' && password === 'password') {
    req.session.isLoggedIn = true;  // บันทึกสถานะล็อกอิน
    req.session.FirstName = 'John'; // เก็บชื่อผู้ใช้ใน session
    res.redirect('/');  // เปลี่ยนเส้นทางไปหน้าแรก
  } else {
    res.send('Invalid credentials');  // หากข้อมูลไม่ถูกต้อง
  }
});

// Logout route
app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.redirect('/');  // หากมีปัญหาในการลบ session
    }
    res.redirect('/login');  // เมื่อออกจากระบบแล้วเปลี่ยนเส้นทางไปหน้าล็อกอิน
  });
});

app.get('/cart', (req, res) => {
  const cartItems = req.session.cart || []; // ดึงข้อมูลสินค้าจากตะกร้าในเซสชัน หรือใช้ตะกร้าว่างถ้าไม่มี
  res.render('cart', {
      cartItems,  // ส่งข้อมูลตะกร้าไปยังหน้า cart.ejs
      isLoggedIn: req.session.isLoggedIn || false, // เช็คการล็อกอินของผู้ใช้
      FirstName: req.session.FirstName || '' // ส่งชื่อผู้ใช้ที่ล็อกอินแล้ว
  });
});
// Search route
app.get('/search', (req, res) => {
  const query = req.query.query ? req.query.query.toLowerCase() : '';

  if (query) {
      const sql = 'SELECT * FROM products WHERE LOWER(ProductName) LIKE ? OR LOWER(Description) LIKE ?'; // Corrected column names to match your schema
      const searchTerm = `%${query}%`; // Store the search term to avoid repetition

      // Use the connection pool to get a connection
      pool.getConnection((err, connection) => {
          if (err) {
              console.error("Error getting database connection:", err); // Log the error for debugging
              return res.status(500).send('Error occurred while searching products');
          }

          connection.query(sql, [searchTerm, searchTerm], (err, results) => {
              connection.release(); // Important: Release the connection back to the pool

              if (err) {
                  console.error("Error executing query:", err); // Log the error
                  return res.status(500).send('Error occurred while searching products');
              }

              res.render('search-results', {
                  products: results,
                  query: query,
                  isLoggedIn: req.session.isLoggedIn || false,
                  FirstName: req.session.FirstName || ''
              });
          });
      });
  } else {
      res.render('search-results', {
          products: [],
          query: query,
          isLoggedIn: req.session.isLoggedIn || false,
          FirstName: req.session.FirstName || ''
      });
  }
});

app.get('/user', (req, res) => {
  res.render('user', {
      user: {
          username: 'pphakarn',
          email: 'pi@gmail.com',
      },
  });
});
// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
