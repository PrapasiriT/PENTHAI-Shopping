const express = require('express');
const router = express.Router();
const session = require('express-session');
const db = require('../db');
const bcrypt = require('bcrypt');

// กำหนดการใช้ session ใน app
router.use(session({
    secret: 'your-secret-key', // คีย์ที่ใช้ในการเข้ารหัส session
    resave: false,             // ไม่ต้องบันทึก session ใหม่ถ้าไม่มีการเปลี่ยนแปลง
    saveUninitialized: true    // ให้บันทึก session เมื่อเริ่มต้นใช้งาน
}));

// ดึงข้อมูลผู้ใช้ทั้งหมด
router.get('/', async (req, res) => {
  try {
    const [users] = await db.query('SELECT * FROM Users');
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// สมัครสมาชิกผู้ใช้ใหม่
router.post('/register', async (req, res) => {
    const { FirstName, LastName, Email, Password } = req.body;

    if (!FirstName || !LastName || !Email || !Password) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    try {
      // เข้ารหัสรหัสผ่าน
      const hashedPassword = await bcrypt.hash(Password, 10);

      const result = await db.query(
        'INSERT INTO Users (FirstName, LastName, Email, Password) VALUES (?, ?, ?, ?)',
        [FirstName, LastName, Email, hashedPassword]
      );

      console.log('User registered successfully!');
      res.redirect('/login'); // ลิงก์ไปหน้า login
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
});

// เข้าสู่ระบบผู้ใช้
router.post('/login', async (req, res) => {
  const { Email, Password } = req.body;

  if (!Email || !Password) {
      return res.status(400).json({ error: 'Email and Password are required' });
  }

  try {
      const [users] = await db.query('SELECT * FROM Users WHERE Email = ?', [Email]);

      if (users.length > 0) {
          const user = users[0];

          const isMatch = await bcrypt.compare(Password, user.Password);
          if (isMatch) {
              // เก็บข้อมูลผู้ใช้ในเซสชัน
              req.session.isLoggedIn = true;
              req.session.UserID = user.UserID;  // เพิ่มข้อมูล UserID ใน session
              req.session.FirstName = user.FirstName;

              console.log('Login successful!');
              res.redirect('/'); // ส่งไปหน้า Home
          } else {
              res.status(401).json({ error: 'Invalid email or password' });
          }
      } else {
          res.status(401).json({ error: 'Invalid email or password' });
      }
  } catch (err) {
      res.status(500).json({ error: err.message });
  }
});


// ป้องกันไม่ให้ผู้ใช้เข้าหน้า login หากล็อคอินแล้ว
router.get('/login', (req, res) => {
  if (req.session.isLoggedIn) {
    // ถ้าเข้าสู่ระบบแล้วให้ไปที่หน้าอื่น
    return res.redirect('/'); // สามารถปรับเป็นหน้าที่ผู้ใช้สามารถเข้าถึงได้หลังล็อคอิน
  }
  res.render('login'); // ถ้ายังไม่ล็อคอินก็ให้แสดงหน้า login
});

// ลบผู้ใช้
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await db.query('DELETE FROM Users WHERE UserID = ?', [id]);
    if (result[0].affectedRows > 0) {
      res.json({ message: 'User deleted successfully!' });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ฟังก์ชันออกจากระบบ (logout)
router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to log out' });
        }
        res.redirect('/'); // หลังจาก logout ให้ส่งผู้ใช้กลับไปหน้า index
    });
});



module.exports = router;
