const express = require('express');
const multer = require('multer');
const path = require('path');
const db = require('../db');

const router = express.Router();

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage });

// Show Add Product Page
router.get('/add', (req, res) => {
  res.render('add-product'); // Render EJS file instead of sending an HTML file directly
});

// Add New Product
router.post('/add', upload.single('ImageURL'), async (req, res) => {
  const { ProductName, Description, Price, CategoryID, StockQuantity } = req.body;
  const ImageURL = req.file ? `/uploads/${req.file.filename}` : null;

  // Log form data and file upload info for debugging
  console.log("Form Data: ", req.body);
  console.log("File Data: ", req.file);

  // Validate form data
  if (!ProductName || !Description || !Price || !CategoryID || !StockQuantity || !ImageURL) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const result = await db.query(
      'INSERT INTO Products (ProductName, Description, Price, CategoryID, StockQuantity, ImageURL) VALUES (?, ?, ?, ?, ?, ?)',
      [ProductName, Description, Price, CategoryID, StockQuantity, ImageURL]
    );

    console.log("Insert Result: ", result);

    res.redirect('/'); // Redirect to index page after adding product
  } catch (err) {
    console.error("Error: ", err);
    res.status(500).json({ error: err.message });
  }
});

// Fetch All Products
router.get('/product', async (req, res) => {
  const isLoggedIn = req.session.isLoggedIn || false;  // ตรวจสอบการเข้าสู่ระบบ
  const FirstName = req.session.FirstName || '';  // ตรวจสอบชื่อผู้ใช้

  try {
    const [products] = await db.query('SELECT * FROM Products');
    
    // เรนเดอร์ไฟล์ EJS พร้อมส่งข้อมูลที่จำเป็น
    res.render('product', { 
      products, 
      isLoggedIn: isLoggedIn, 
      FirstName: FirstName 
    });
  } catch (err) {
    console.error("Error: ", err);
    res.status(500).json({ error: err.message });
  }
});


// Fetch Product Details
router.get('/product/:id', async (req, res) => {
  const { id } = req.params;
  const isLoggedIn = req.session.isLoggedIn || false;  // ตรวจสอบสถานะการล็อกอิน
  const FirstName = req.session.FirstName || ''; // ชื่อผู้ใช้

  try {
    const [product] = await db.query('SELECT * FROM Products WHERE ProductID = ?', [id]);
    if (product.length > 0) {
      // ส่งข้อมูล isLoggedIn และ FirstName ไปพร้อมกับข้อมูลผลิตภัณฑ์
      res.render('product_details', { 
        product: product[0], 
        isLoggedIn: isLoggedIn, 
        FirstName: FirstName 
      });
    } else {
      res.status(404).json({ message: 'Product not found' });
    }
  } catch (err) {
    console.error("Error: ", err);
    res.status(500).json({ error: err.message });
  }
});

// Show Products by Category
router.get('/category/:CategoryID', async (req, res) => {
  const { CategoryID } = req.params;
  const isLoggedIn = req.session.isLoggedIn || false;
  const FirstName = req.session.FirstName || '';

  try {
    // ดึงข้อมูลสินค้าตาม CategoryID และชื่อหมวดหมู่
    const [products] = await db.query('SELECT * FROM Products WHERE CategoryID = ?', [CategoryID]);

    // ดึงชื่อหมวดหมู่จากฐานข้อมูล
    const [category] = await db.query('SELECT CategoryName FROM Categories WHERE CategoryID = ?', [CategoryID]);

    // ตรวจสอบว่ามีการดึงข้อมูลหมวดหมู่หรือไม่
    const categoryName = category.length > 0 ? category[0].CategoryName : 'Unknown Category';

    res.render('category_products', { 
      products, 
      categoryId: CategoryID, 
      isLoggedIn: isLoggedIn, 
      FirstName: FirstName,
      categoryName: categoryName  // ส่งชื่อหมวดหมู่ไปยัง EJS
    });
  } catch (err) {
    console.error("Error: ", err);
    res.status(500).send('Internal Server Error');
  }
});

// Route สำหรับเพิ่มสินค้าลงในตะกร้า
router.post('/add-to-cart', async (req, res) => {
  const { ProductID, quantity } = req.body;

  if (!req.session.isLoggedIn) {
    return res.status(401).json({ error: 'คุณต้องเข้าสู่ระบบก่อนถึงจะเพิ่มสินค้าลงในตะกร้าได้' });
  }

  const userID = req.session.UserID; // ดึง UserID จาก session

  try {
    const [product] = await db.query('SELECT * FROM Products WHERE ProductID = ?', [ProductID]);
    
    if (product.length === 0) {
      return res.status(404).json({ error: 'ไม่พบสินค้าที่คุณต้องการ' });
    }

    const productName = product[0].ProductName;
    const imageURL = product[0].ImageURL;
    const price = product[0].Price;

    const [existingItem] = await db.query('SELECT * FROM cart_items WHERE UserID = ? AND ProductID = ?', [userID, ProductID]);

    if (existingItem.length > 0) {
      await db.query(
        'UPDATE cart_items SET Quantity = Quantity + ?, Price = ? WHERE UserID = ? AND ProductID = ?',
        [quantity, price, userID, ProductID]
      );
    } else {
      await db.query(
        'INSERT INTO cart_items (UserID, ProductID, ProductName, ImageURL, Price, Quantity) VALUES (?, ?, ?, ?, ?, ?)',
        [userID, ProductID, productName, imageURL, price, quantity]
      );
    }

    res.redirect('/cart');
  } catch (err) {
    console.error("Error adding product to cart:", err);
    res.status(500).json({ error: 'เกิดข้อผิดพลาดในการเพิ่มสินค้าลงในตะกร้า' });
  }
});

router.get('/cart', async (req, res) => {
  if (!req.session.isLoggedIn) {
      return res.redirect('/login');
  }

  const userID = req.session.UserID; // Get UserID from session

  try {
      const [cartItems] = await db.query(`
          SELECT 
              c.CartID, 
              p.ProductName, 
              p.ImageURL, 
              p.Price, 
              c.Quantity,
              FROM cart_items c
          JOIN products p ON c.ProductID = p.ProductID
          WHERE c.UserID = ?
      `, [UserID]);

      // ไม่คำนวณ total อีกต่อไป
      res.render('cart', {
          cartItems,
          isLoggedIn: req.session.isLoggedIn,
          FirstName: req.session.FirstName || ''
      });
  } catch (err) {
      console.error('Error fetching cart items:', err);
      res.status(500).send('Internal Server Error');
  }
});




module.exports = router;
