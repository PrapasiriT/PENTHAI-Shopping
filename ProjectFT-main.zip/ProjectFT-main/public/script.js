document.querySelector("#myCarousel")

function addToCart() {
    alert("Item added to cart!");
}